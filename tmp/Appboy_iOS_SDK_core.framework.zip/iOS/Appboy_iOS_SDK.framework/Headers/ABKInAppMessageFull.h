#import "ABKInAppMessageImmersive.h"

/*
 * Braze Public API: ABKInAppMessageFull
 */
NS_ASSUME_NONNULL_BEGIN
@interface ABKInAppMessageFull : ABKInAppMessageImmersive

@end
NS_ASSUME_NONNULL_END
