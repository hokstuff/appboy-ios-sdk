#import "ABKInAppMessage.h"

/*
 * Braze Public API: ABKInAppMessageControl
 */
@interface ABKInAppMessageControl : ABKInAppMessage

@end
